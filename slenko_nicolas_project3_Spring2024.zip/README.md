Name: Nicolas Slenko
Section: 10828
UFL email: nslenko@ufl.edu
System: Windows
Compiler: g++ 
SFML version: 2.5.1
IDE: CLion
Other:
    Timer works for the most part, but has difficulties if you click on the pause and unpause too fast
    Diego please bless me up <3 